<?php
if ( ! defined( 'ABSPATH' ) ) :
	exit;
endif;

/*
 * Plugin Name: WooCommerce Clean Urls
 * Plugin URI: https://weblogiq.nl/plugins/woocommerce-url-cleaner/
 * Description: Cleans WooCommerce Urls by removing <strong>product</strong> and <strong>product-category</strong> and redirects the old URL to the new URL to maintain the grown SEO value.
 * Version: 1.0.1
 * Author: Weblogiq / BMC
*/

foreach ( glob( plugin_dir_path( __FILE__ ) . "lib/*.php" ) as $file ) :
    include_once $file;
endforeach;

defined('PLUGIN_CAN_EXECUTE') and new init or new wbaseAdmin;

?>